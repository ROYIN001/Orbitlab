import { bank } from './assessment-inventory.mjs';
import { writeFileSync, readFileSync } from 'node:fs';
const { evaluate } = await import('./source/src/lessons/assessment/expression.ts');
const { prepareQuestion, drawTest, rng } = await import('./source/src/lessons/assessment/draw.ts');
const { isCorrect, gradeQuestion, numericExpected, scoreAttempt } = await import('./source/src/lessons/assessment/score.ts');
const { diagramSvg, DIAGRAM_IDS } = await import('./source/src/lessons/assessment/diagrams.ts');
const errors = [], check = (ok, msg) => { if (!ok) errors.push(msg); };
const ids = new Set(), byId = new Map(bank.map(q => [q.id,q]));
const MU = 398600.4418e9, R = 6378137;
const ds = d => Math.sin(d * Math.PI / 180), dc = d => Math.cos(d * Math.PI / 180);
const flight = JSON.parse(readFileSync(new URL('./source/src/lessons/assessment/flights.json', import.meta.url),'utf8'));
const reference = {
 'b-gravity-altitude': p => 9.81 / ((6378+p.h)/6378)**2,
 'o-circular-speed': p => Math.sqrt(MU / (R + p.h*1000)) / 1000,
 'o-period': p => Math.sqrt(4*Math.PI*Math.PI*(R+p.h*1000)**3/MU)/60,
 'o-hohmann-first': p => {const r1=R+p.h1*1000,r2=R+p.h2*1000; return Math.sqrt(MU*(2/r1-2/(r1+r2)))-Math.sqrt(MU/r1);},
 'o-plane-change': p => {const v=p.v*1000; return Math.hypot(v*ds(p.di),v*(1-dc(p.di)));},
 'o-perigee-speed': p => {const rp=R+p.hp*1000,ra=R+p.ha*1000; return Math.sqrt(2*MU*ra/(rp*(rp+ra)))/1000;},
 'o-ground-track': p => Math.asin(ds(p.i))*180/Math.PI,
 'o-period-height': p => (Math.cbrt(MU*((p.T*3600)/(2*Math.PI))**2)-R)/1000,
 'r-tsiolkovsky-calc': p => p.isp*9.81*(Math.log(p.m0)-Math.log(p.mf)),
 'r-mass-ratio': p => Math.E**(p.dv/(9.81*p.isp)),
 'r-q-calc': p => p.rho*(p.v*p.v)/2000,
 'r-read-maxq': () => Math.max(...flight['f9-leo'].series.q),
 'r-read-meco': () => flight['f9-leo'].events.find(e=>e[1]==='evt.meco')[0],
 'r-liftoff-accel': p => (p.F*1000-p.m*1000*9.81)/(p.m*1000),
 'g-ins-error': p => ((p.b*9.81/1000)*p.t)*(p.t/2)/1000,
 'g-launch-azimuth': p => Math.asin(dc(p.i)/dc(p.phi))*180/Math.PI,
 'c-overshoot': p => 100*Math.exp(-p.z*Math.PI/Math.sqrt((1-p.z)*(1+p.z))),
 'c-gain-db': p => 20*Math.log(p.k)/Math.LN10,
 'c-delay-phase': p => (p.tau/1000)/(2*Math.PI/p.w)*360,
 'c-read-overshoot': p => 100*Math.exp(-p.z*Math.PI/Math.sqrt((1-p.z)*(1+p.z))),
 'c-read-pm': p => {let lo=0,hi=100;for(let n=0;n<100;n++){const w=(lo+hi)/2;if(w*Math.sqrt(1+0.25*w*w)>p.K)hi=w;else lo=w;} return 90-Math.atan(0.5*(lo+hi)/2)*180/Math.PI;},
 'c-pd-damping': p => 0.5*p.kd*p.kp**-0.5,
 'c-tvc-moment': p => p.l*(p.F*ds(p.d)),
 'f-voting-reliability': p => {const r=p.p/100; return 100*(r*r*r+3*r*r*(1-r));},
 'f-series-reliability': p => {let r=1; for(let i=0;i<p.n;i++)r*=p.p/100;return 100*r;},
};
let textTriples=0, blankOrMissing=0;
const numericRows=[], allRows=[];
for(const q of bank){
 check(!ids.has(q.id),q.id+': duplicate ID'); ids.add(q.id);
 const texts=[q.prompt,q.explanation,...(q.options??[]).flatMap(o=>[o.text,...(o.misconception?[o.misconception]:[])]),...(q.items??[])];
 for(const [i,t] of texts.entries()){
   textTriples++;
   for(const lang of ['en','ru','th']) { if(typeof t[lang]!=='string'||!t[lang].trim())blankOrMissing++; check(typeof t[lang]==='string'&&!!t[lang].trim(),q.id+': empty '+i+' '+lang); }
   const placeholders = s => [...s.matchAll(/\{(\w+)\}/g)].map(m=>m[1]).sort().join(',');
   check(placeholders(t.en)===placeholders(t.ru)&&placeholders(t.en)===placeholders(t.th),q.id+': placeholder difference '+i);
 }
 if(q.options) {
   check(q.options.filter(o=>o.correct).length===(q.type==='choice'?1:q.options.filter(o=>o.correct).length),q.id+': correct cardinality');
   if(q.type==='multi')check(q.options.filter(o=>o.correct).length>=2&&q.options.some(o=>!o.correct),q.id+': multi cardinality');
   for(const lang of ['en','ru','th'])check(new Set(q.options.map(o=>o.text[lang])).size===q.options.length,q.id+': duplicate '+lang+' options');
 }
 let combos=0,min=Infinity,max=-Infinity,maxRelativeError=0;
 if(q.type==='numeric') {
   check(!!reference[q.id],q.id+': missing independent reference');
   const walk=(ix,values)=>{
     if(ix<q.params.length){const p=q.params[ix],n=Math.round((p.max-p.min)/p.step);for(let k=0;k<=n;k++)walk(ix+1,{...values,[p.name]:Number((p.min+k*p.step).toFixed(8))});return;}
     combos++;const expected=evaluate(q.answer,values),ref=reference[q.id](values),p={id:q.id,values};
     min=Math.min(min,expected);max=Math.max(max,expected);
     const rel=Math.abs(expected-ref)/Math.max(1,Math.abs(ref));maxRelativeError=Math.max(maxRelativeError,rel);
     check(Number.isFinite(expected)&&expected>0,q.id+': invalid '+JSON.stringify(values));
     check(rel<(q.id==='r-liftoff-accel'?0.0012:1e-10),q.id+': reference discrepancy '+JSON.stringify(values));
     check(isCorrect(q,p,{id:q.id,value:ref}),q.id+': rejects reference');
     check(!isCorrect(q,p,{id:q.id,value:expected*(1+q.tolPct/100+0.001)}),q.id+': accepts out of tolerance');
   };walk(0,{});
   numericRows.push({id:q.id,combos,min,max,maxRelativeError,unit:q.unit,tolerancePct:q.tolPct,formula:q.answer});
 }
 for(let seed=0;seed<100;seed++){
   const p=prepareQuestion(q,rng(seed));
   if(q.type==='numeric')for(const x of q.params){const v=p.values[x.name];check(v>=x.min-1e-9&&v<=x.max+1e-9,q.id+': generated range');check(Math.abs((v-x.min)/x.step-Math.round((v-x.min)/x.step))<1e-7,q.id+': step');}
   if(q.type==='order')check(!p.order.every((v,i)=>v===i),q.id+': initially ordered');
   if(q.type==='vehicle')check(new Set(p.vehicleOptions).size===4&&p.vehicleOptions.includes(p.vehicle),q.id+': vehicle choices');
   for(const fig of [q.figure,q.observe])if(fig?.kind==='diagram')check(/^<svg/.test(diagramSvg(fig.id,p.values)||'')&&!/NaN|Infinity/.test(diagramSvg(fig.id,p.values)),q.id+': invalid diagram');
 }
 allRows.push({id:q.id,source:q.source,line:q.line,domain:q.domain,level:q.level,type:q.type,kind:q.kind,skill:q.skill,numericCombinations:combos,lessonLinks:q.lessons??[],figures:[q.figure,q.observe].filter(Boolean)});
}
let drawChecks=0;const seen=new Set();let overlap=0;
for(let seed=1;seed<=1000;seed++){
 const pre=drawTest(bank,seed),post=drawTest(bank,seed+1000,new Set(pre.map(p=>p.id)));
 check(pre.length===25&&new Set(pre.map(p=>p.id)).size===25,'draw '+seed+': count');
 for(const p of pre)seen.add(p.id);
 overlap+=post.filter(p=>pre.some(a=>a.id===p.id)).length;drawChecks++;
}
const plainScores=[];
for(let seed=1;seed<=100;seed++){
 const questions=drawTest(bank,seed);
 const answers=questions.map(p=>{const q=byId.get(p.id);let value;
 if(q.type==='choice')value=q.options.findIndex(o=>o.correct);
 if(q.type==='multi')value=q.options.flatMap((o,i)=>o.correct?[i]:[]).join(',');
 if(q.type==='order')value=q.items.map((_,i)=>i).join(',');
 if(q.type==='vehicle')value=p.vehicle;
 if(q.type==='numeric')value=numericExpected(q,p);
 return {id:q.id,value,...(q.kind==='understanding'?{confidence:'guess'}:{})};});
 const r=scoreAttempt({kind:'pre',seed,startedAt:'2026-09-28',questions,answers},bank,[]);
 plainScores.push({seed,correct:r.questions.filter(q=>q.correct).length,percent:r.percent,understanding:questions.filter(p=>byId.get(p.id).kind==='understanding').length});
}
const result={bankCount:bank.length,textTriples,blankOrMissing,uniqueIds:ids.size,numericFamilies:numericRows.length,numericCombinations:numericRows.reduce((s,r)=>s+r.combos,0),numericRows,drawChecks,postOverlap:overlap,idsReached:seen.size,diagrams:DIAGRAM_IDS.length,correctButGuessScoreRange:[Math.min(...plainScores.map(s=>s.percent)),Math.max(...plainScores.map(s=>s.percent))],plainScores,errors,inventory:allRows};
writeFileSync(new URL('./assessment-systematic-results.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,inventory:undefined,numericRows:undefined,plainScores:undefined},null,2));
console.log('Detailed 25-family numeric grid and all 157 item rows: assessment-systematic-results.json');
if(errors.length)process.exitCode=1;
