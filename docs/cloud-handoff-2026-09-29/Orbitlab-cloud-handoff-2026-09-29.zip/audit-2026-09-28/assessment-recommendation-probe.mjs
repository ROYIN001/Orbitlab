import { bank } from './assessment-inventory.mjs';
import { writeFileSync, readFileSync } from 'node:fs';
// Only the fields scoreAttempt consumes, extracted from every builtin track.
const lessons=[];
for(let i=1;i<=6;i++){
 const text=readFileSync(new URL(`./source/src/lessons/builtin/track${i}.ts`,import.meta.url),'utf8');
 for(const m of text.matchAll(/id: '([^']+)', track: (\d+), order: (\d+),[^\n]*?domains: \[([^\]]+)\]/g))lessons.push({id:m[1],track:Number(m[2]),order:Number(m[3]),domains:m[4].split(',').map(Number)});
}
const { drawTest } = await import('./source/src/lessons/assessment/draw.ts');
const { scoreAttempt, numericExpected } = await import('./source/src/lessons/assessment/score.ts');
const byId=new Map(bank.map(q=>[q.id,q]));
let seed=1,questions=[];
for(;seed<1000;seed++){questions=drawTest(bank,seed);if(questions.some(p=>p.id==='b-launch-east'))break;}
const answers=questions.map(p=>{const q=byId.get(p.id);let value;
 if(q.type==='choice')value=q.options.findIndex(o=>o.correct);
 if(q.type==='multi')value=q.options.flatMap((o,i)=>o.correct?[i]:[]).join(',');
 if(q.type==='order')value=q.items.map((_,i)=>i).join(',');
 if(q.type==='vehicle')value=p.vehicle;
 if(q.type==='numeric')value=numericExpected(q,p);
 if(q.id==='b-launch-east')value=1;
 return {id:q.id,value,...(q.kind==='understanding'?{confidence:'unsure'}:{})};});
const r=scoreAttempt({kind:'pre',seed,startedAt:'2026-09-28',questions,answers},bank,lessons);
const result={seed,lessonMetadataCount:lessons.length,percent:r.percent,start:r.start,startDomain:r.startDomain,domains:r.domains,advice:r.advice};
console.log(JSON.stringify(result,null,2));
writeFileSync(new URL('./assessment-recommendation-probe.json',import.meta.url),JSON.stringify(result,null,2));
