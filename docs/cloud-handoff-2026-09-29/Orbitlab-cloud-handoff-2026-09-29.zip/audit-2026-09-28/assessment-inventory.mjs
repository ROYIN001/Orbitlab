import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { fileURLToPath } from 'node:url';

// Audit-only loader: execute read-only source modules using installed Node 24.
registerHooks({
  resolve(specifier, context, next) {
    if (specifier.startsWith('.') && !/\.(ts|json|js|mjs)$/.test(specifier)) {
      const url = new URL(specifier + '.ts', context.parentURL);
      if (existsSync(url)) return { url: url.href, shortCircuit: true };
      const index = new URL(specifier + '/index.ts', context.parentURL);
      if (existsSync(index)) return { url: index.href, shortCircuit: true };
    }
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.endsWith('.ts')) return { format: 'module', source: stripTypeScriptTypes(readFileSync(new URL(url), 'utf8'), { mode: 'transform' }), shortCircuit: true };
    if (url.endsWith('.json')) return { format: 'module', source: 'export default ' + readFileSync(new URL(url), 'utf8'), shortCircuit: true };
    return next(url, context);
  },
});

const files = ['basics', 'orbits', 'rockets', 'guidance', 'control', 'failures'];
const bank = [];
for (const file of files) {
  const src = new URL(`./source/src/lessons/assessment/bank/${file}.ts`, import.meta.url);
  const text = readFileSync(src, 'utf8');
  const mod = await import(src.href);
  for (const q of mod[file.toUpperCase()]) {
    const pos = text.indexOf(`('${q.id}',`);
    bank.push({ ...q, source: `src/lessons/assessment/bank/${file}.ts`, line: text.slice(0, pos).split('\n').length });
  }
}
writeFileSync(new URL('./assessment-bank-inventory.json', import.meta.url), JSON.stringify(bank, null, 2));
for (const lang of ['en', 'ru', 'th']) {
  const out = bank.map(q => `${q.id} | domain ${q.domain} level ${q.level} ${q.type} ${q.kind} | ${q.source}:${q.line}\n${q.prompt[lang]}\n` +
    (q.options ? q.options.map((o, i) => `${i}${o.correct ? '*' : ''}: ${o.text[lang]}${o.misconception ? ' [MIS: ' + o.misconception[lang] + ']' : ''}`).join('\n') + '\n' : '') +
    (q.items ? 'ORDER: ' + q.items.map(x => x[lang]).join(' → ') + '\n' : '') +
    (q.vehicles ? 'VEHICLES: ' + q.vehicles.join(', ') + '\n' : '') +
    (q.type === 'numeric' ? 'PARAMS: ' + JSON.stringify(q.params) + '\nANSWER: ' + q.answer + ' ' + q.unit + ', tolerance ' + q.tolPct + '%\n' : '') +
    (q.figure ? 'FIGURE: ' + JSON.stringify(q.figure) + '\n' : '') +
    (q.observe ? 'OBSERVE: ' + JSON.stringify(q.observe) + '\n' : '') +
    'EXPLAIN: ' + q.explanation[lang] + '\nLESSONS: ' + (q.lessons ?? []).join(', ')).join('\n\n');
  writeFileSync(new URL(`./assessment-bank-${lang}.txt`, import.meta.url), out);
}
const summary = files.map((file, i) => {
  const qs = bank.filter(q => q.domain === i + 1);
  return { domain: i + 1, file, total: qs.length, levels: [1, 2, 3].map(l => qs.filter(q => q.level === l).length), types: Object.fromEntries(['choice','numeric','multi','order','vehicle'].map(t => [t, qs.filter(q => q.type === t).length])), understanding: qs.filter(q => q.kind === 'understanding').length, lessonsLinked: qs.filter(q => q.lessons?.length).length };
});
console.log(JSON.stringify({ count: bank.length, summary }, null, 2));
export { bank };
