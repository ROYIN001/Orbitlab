# Orbitlab — งานกราฟิกและจุดส่งต่อ 29 กันยายน 2026

**สถานะ: มีการแก้ source บางส่วนแล้ว ผ่าน TypeScript และ existing render tests; ยังไม่ได้ตรวจภาพจริงผ่านเบราว์เซอร์ งานกราฟิกทั้งหมดจึงยังไม่เสร็จ** หยุดแก้ตามคำสั่งย้ายงานไป Codex Cloud และบันทึกสถานะนี้เพื่อรวมใน portable snapshot ไม่มี push/deploy จากงานย่อยนี้

## ขอบเขตที่อ่าน

อ่านรายงาน 28 กันยายน และ source ของ Launch (`src/render/scene.ts`, `sky.ts`, `lines.ts`), Orbit (`src/render/orbit-view.ts`), Build (`src/ui/build/stack-svg.ts`, `build.css`) รวมถึง render tests ที่เกี่ยวข้อง ผู้ใช้อนุญาตแก้บั๊กและปรับคุณภาพกราฟิกที่มีอยู่ ส่วนฟีเจอร์ใหม่ต้องรายงานก่อน

Launch มี physical atmosphere, ACES, bloom, MSAA 4 samples, Earth relief, เงาและ Earth-shine อยู่แล้ว จึงรักษาระบบเหล่านี้ไว้ Orbit มี renderer ของตัวเอง ส่วน Build ใช้ SVG ตามสัดส่วน

## สิ่งที่แก้แล้วใน working tree

| ไฟล์ | การเปลี่ยนแปลง | เหตุผลและขอบเขตยืนยัน |
|---|---|---|
| `source/src/render/stars.ts` (ใหม่) | ย้าย deterministic star field และ shaders เดิมของ Launch มารวมเป็นโมดูล ใช้ radius ที่ส่งเข้าได้ เพิ่ม `uPixelRatio` ให้ point sizes เป็น CSS pixels | ข้อมูลตำแหน่ง สี และ magnitude เดิมของ Launch ไม่เปลี่ยน; เป็นภาพประกอบ ไม่ใช่ star catalogue ทางดาราศาสตร์ |
| `source/src/render/scene.ts` | ใช้โมดูลดาวร่วม ตั้ง/อัปเดต `uPixelRatio` ให้ตรง renderer | แก้ `gl_PointSize` เดิมที่เป็น device pixels ทำให้ CSS size เล็กลงเมื่อ DPR สูง; pipeline แสงและฟิสิกส์ไม่เปลี่ยน |
| `source/src/render/orbit-view.ts` | ใช้ดาวขอบนุ่ม/สีและความสว่างหลายระดับจากโมดูลเดียวกับ Launch แทนจุดสี่เหลี่ยม 1,800 จุดสีเดียว | เปลี่ยนเป็น 6,000 จุดตามชุด Launch เดิม; ยังต้องประเมินภาพและประสิทธิภาพจริง โดยเฉพาะเครื่องช้า |
| `source/src/render/orbit-view.ts` | อ่าน DPR ใน `render()` และปรับ renderer/ดาวเมื่อค่าเปลี่ยน | เดิมอ่านครั้งเดียวตอน constructor; ครอบคลุมย้ายจอที่ CSS box ไม่เปลี่ยน ซึ่ง ResizeObserver ไม่เรียก |
| `source/src/render/orbit-view.ts` | dispose material พร้อม geometry ของ equal-time sectors ก่อนสร้างใหม่ | แก้ทรัพยากรเก่าที่ไม่ได้ dispose เมื่อเปลี่ยนวงโคจรหรือสลับ sectors |

ยังไม่มีการแก้ `stack-svg.ts` หรือ CSS ของ Build และยังไม่ปรับ Earth shader ของ Orbit

## ผลตรวจที่รันจริงหลังแก้

รันจาก `audit-2026-09-29/source` ด้วย Node `C:/Program Files/nodejs/node.exe`:

- `node node_modules/typescript/bin/tsc --noEmit` — ผ่าน exit 0
- `node node_modules/vitest/vitest.mjs run tests/rigid-render.test.ts tests/ship-render.test.ts tests/soyuz-render.test.ts tests/sky.test.ts` — **4 ไฟล์ 22 tests ผ่านทั้งหมด**, 3.49 วินาที เริ่ม 02:53:15 ตามนาฬิกาเครื่อง

นี่เป็น existing regression ของ transforms/geometry/sky helpers ไม่ได้ทดสอบ WebGL shader compilation, DPR, sectors disposal หรือคุณภาพภาพโดยตรง จึงห้ามตีความเป็นการตรวจรับภาพใหม่ครบถ้วน

## สิ่งที่ค้างและขั้นทำต่อใน Cloud

1. อ่าน diff ของสามไฟล์ด้านบนก่อนแก้เพิ่ม; อย่าย้อนทับ dirty changes ของงานอื่น
2. เพิ่ม focused tests ของ DPR lifecycle และ material disposal โดยเรียก production methods พร้อม renderer stub; ทดสอบว่าดาวคงตำแหน่งเมื่อใช้ radius ต่างกัน และมี finite values ทุก attribute
3. เริ่ม local preview ของ snapshot ใช้ browser ที่ Cloud รองรับ ตรวจ Launch, Orbit, Home globe, Build ทั้ง desktop/mobile; ตรวจ console ว่าไม่มี shader errors และ canvas ไม่ดำ
4. ตรวจภาพ DPR 1/2 และเปลี่ยน DPR หลังสร้าง renderer; ขนาดดาว/เส้นควรอ่านได้โดยไม่ขยายมากผิดสัดส่วน ทดสอบเล่น/หยุดและสลับ workspace ซ้ำ
5. ตรวจ Orbit ทั้งวงโคจรกลม/รี, Kepler sectors เปิดปิด, ghost transfer และ catalogue เพื่อดูว่าดาวพื้นหลังไม่บดบัง marker/เส้นสำคัญ
6. เทียบกับ source ก่อนแก้หรือเว็บเดิม บันทึกภาพก่อน/หลังและหลักฐานการทำซ้ำ; ปรับจำนวน/ความเข้มดาวหากภาพรกหรือช้าลง
7. ปรับ Build SVG แบบบาง ๆ ให้เห็นทรงกระบอก/engine bell โดยคงสีเดิม สัดส่วน selection และ keyboard focus; ทดสอบ geometry/label รวมทั้งทุก vehicle 21 รุ่น
8. ปรับ Launch/Earth เฉพาะจุดที่ภาพจริงยืนยันว่ามีประโยชน์ ไม่เพิ่มเอฟเฟกต์ซ้ำหรือเปลี่ยนฟิสิกส์
9. อัปเดตรายงานนี้และรายงานหลักว่าอะไรผ่านจริง อะไรยังจำกัด พร้อมตำแหน่งไฟล์ภาพ/ผลทดสอบ

## สิ่งที่ไม่ควรกล่าวอ้าง ณ จุดส่งต่อ

- ยังไม่มีภาพ before/after หรือ browser validation จาก source รอบนี้
- ยังไม่ทดสอบความเร็ว GPU/อุปกรณ์จริงหลายรุ่น
- ยังไม่ปรับกราฟิกครบทุก simulation/ทุก workspace
- ยังไม่ deploy รุ่นใหม่ จึงไม่มีหลักฐานว่าเว็บจริงแสดงการแก้เหล่านี้แล้ว

ไม่มี server หรือ background process ที่เริ่มโดยงานกราฟิกนี้ คำสั่งตรวจสองชุดจบแล้ว
