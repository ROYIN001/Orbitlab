import { registerHooks, stripTypeScriptTypes } from 'node:module';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
registerHooks({
  resolve(specifier, context, next) {
    if (specifier.startsWith('.') && !/\.(ts|json|js|mjs)$/.test(specifier)) {
      for (const suffix of ['.ts', '/index.ts']) {
        const url = new URL(specifier + suffix, context.parentURL);
        if (existsSync(url)) return { url: url.href, shortCircuit: true };
      }
    }
    return next(specifier, context);
  },
  load(url, context, next) {
    if (url.endsWith('.ts')) return { format: 'module', source: stripTypeScriptTypes(readFileSync(new URL(url), 'utf8'), { mode: 'transform' }), shortCircuit: true };
    if (url.endsWith('.json')) return { format: 'module', source: 'export default ' + readFileSync(new URL(url), 'utf8'), shortCircuit: true };
    return next(url, context);
  },
});
const before = JSON.parse(readFileSync(new URL('../audit-2026-09-28/assessment-bank-inventory.json', import.meta.url)));
const after = [];
for (const file of ['basics', 'orbits', 'rockets', 'guidance', 'control', 'failures']) {
  const module = await import(`./source/src/lessons/assessment/bank/${file}.ts`);
  after.push(...module[file.toUpperCase()]);
}
const structure = (q) => JSON.stringify({
  id: q.id, type: q.type, domain: q.domain, level: q.level, kind: q.kind, skill: q.skill,
  options: q.options?.map((o) => !!o.correct), items: q.items?.length,
  params: q.params, answer: q.answer, unit: q.unit, tolPct: q.tolPct,
  vehicles: q.vehicles, fixedOrder: q.fixedOrder, lessons: q.lessons,
});
const oldById = new Map(before.map((q) => [q.id, q]));
const changed = after.filter((q) => structure(q) !== structure(oldById.get(q.id))).map((q) => q.id);
let triples = 0;
const missing = [], placeholders = [];
function walk(v, id) {
  if (!v || typeof v !== 'object') return;
  if ('en' in v) {
    triples++;
    for (const lang of ['en', 'ru', 'th']) if (typeof v[lang] !== 'string' || !v[lang].trim()) missing.push(`${id}:${lang}`);
    const keys = (s) => JSON.stringify([...s.matchAll(/\{([^}]+)\}/g)].map((m) => m[1]).sort());
    if (keys(v.en) !== keys(v.ru) || keys(v.en) !== keys(v.th)) placeholders.push(id);
  } else for (const child of Object.values(v)) walk(child, id);
}
for (const q of after) walk(q, q.id);
const result = { questions: after.length, oldQuestions: before.length, scoringStructureChanged: changed, textTriples: triples, missingText: missing, placeholderMismatch: placeholders };
writeFileSync(new URL('./learning-bank-compatibility.json', import.meta.url), JSON.stringify(result, null, 2));
console.log(JSON.stringify(result));
if (changed.length || missing.length || placeholders.length || after.length !== before.length) process.exitCode = 1;
