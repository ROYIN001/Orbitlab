# Orbitlab — จุดทำต่อ / resume checkpoint

บันทึก 29 กันยายน 2026 (Europe/Moscow) ระหว่างการตรวจและแก้ไข ยังไม่ใช่ผลตรวจรับสุดท้าย

## คำสั่งผู้ใช้และขอบเขต
อ่าน audit-2026-09-28/Orbitlab-audit-TH.md ทดสอบช่องว่างที่รายงานระบุอย่างละเอียด แก้บั๊ก/เนื้อหาที่พิสูจน์ได้ว่าผิดและยกระดับกราฟิกของการจำลองได้ ส่วนฟีเจอร์/การพัฒนาใหม่ให้เสนอในรายงานก่อน ไม่ได้อนุญาต push/deploy เป็นพิเศษ

ผู้ใช้ถามว่าสามารถปิดเครื่องไปนอนได้ไหม: แจ้งแล้วว่าทดสอบรันบนเครื่องนี้ การปิดเครื่องหรือ Sleep จะทำให้ไม่รันต่อระหว่างนั้น ยังไม่ได้รับคำสั่งหยุดงานชัดเจน ณ การบันทึกนี้

## โฟลเดอร์ที่ต้องใช้
- ซอร์สที่กำลังแก้: audit-2026-09-29/source (Git checkout, origin https://github.com/ROYIN001/Orbitlab.git)
- Base commit: 0a6d1a709ffbf88e8e36f606d6993bd27e5c25e0
- รายงานเดิม: audit-2026-09-28/Orbitlab-audit-TH.md พร้อม appendices
- ผลงาน/หลักฐานรอบนี้: audit-2026-09-29/
- Runtime: C:/Program Files/nodejs/node.exe และ npm ใน PATH; node_modules มีอยู่แล้ว
- อย่า reset/clean/checkout ทับ dirty files: เป็นงานแก้ที่พบอยู่แล้วตั้งแต่เริ่มรอบนี้และงานที่ตรวจต่อ

## สถานะที่ตรวจพบจริง
1. source มี dirty changes 19 tracked files และ 2 untracked ในช่วงเริ่มตรวจ: design store, tunnel, Build engineer refresh, lesson drafts/rubric/progress, assessment score/review, Monte Carlo worker cleanup และ tests ยังไม่ผ่าน full verification
2. fleet-run.log และ heavy-run.log เป็นงานที่เริ่มอยู่ก่อนช่วงสนทนาปัจจุบันและยังโต มี node workers รันอยู่ ไม่เริ่มซ้ำจนตรวจว่าหยุดหรือจบแล้ว
3. มี lessons-sixdof-results.json, build-regressions.json, live-evidence.json อยู่ก่อนแล้ว ต้องอ่าน provenance และตรวจซ้ำส่วนที่เปลี่ยน อย่านับเป็นการทดสอบใหม่เพียงเพราะไฟล์มีอยู่
4. เว็บจริงเปิดได้ใน in-app browser ที่ https://royin001.github.io/Orbitlab/#/launch/engineer มี 21 vehicles และ WebMCP; web text fetch เข้า Pages ไม่ได้แต่ browser เข้าได้
5. ยังไม่เริ่ม standard full suite รอบนี้ ยังไม่เริ่ม local preview server รอบนี้ ยังไม่ push/deploy และยังไม่อัปเดตรายงานหลักว่าผ่านทั้งหมด
6. ไม่มี AGENTS.md พบจาก rg --files ใน workspace

## การแบ่งงานและจุดทำต่อ
- physics_validation: ตรวจ full heavy/sixdof fleet logs, all 21 vehicles, recovery, 7 sixdof lessons, parameter coverage; investigate hash/CRLF fixture failures vs physics failures; report physics-validation-TH.md
- learning_content: ตรวจ existing lesson/assessment changes; แก้ข้อผิดพลาดที่ยืนยันได้; รักษา question IDs, option order และ scoring keys เดิม; deferred policy reveal และ bank snapshot/version feature; report learning-validation-TH.md
- graphics_quality: existing graphics quality in Launch/Orbit/Build; render sources and src/ui/build/stack-svg.ts; report graphics-validation-TH.md
- root: ตรวจ existing Build store/bench/tunnel fixes, Orbit tools, import/export via browser, responsive/accessibility, mission-result time labels; full standard tests/build; consolidate updated Thai audit and patch/diff

## วิธีเริ่มต่อ
1. อ่าน checkpoint นี้และรายงานย่อยใหม่ที่มีอยู่ ตรวจ git status/diff ใน source ก่อนแก้
2. ตรวจว่า fleet/heavy log จบมี summary หรือเป็น log ที่ขาดกลางทาง; ตรวจ process ก่อนเริ่มงานซ้ำ
3. ถ้าปิดเครื่องแล้ว tests ถูกตัดกลางทาง ให้รัน suites ใหม่ตาม package scripts และบันทึก fresh log แยก run; อย่ารวม partial count เป็น passed suite
4. npm run typecheck, npm test (จำกัด workers เมื่อ heavy runs ใช้ CPU), npm run test:heavy, npm run test:sixdof-fleet ตามความจำเป็น; inspect config ก่อน run
5. browser UI ใช้ cua_repl; อย่าเปิด Playwright browser ผ่าน shell หรืออื่นแทนช่องทาง UI ที่กำหนด
6. ทำ local preview แล้วตรวจบั๊กก่อน/หลังและ UI flows, render screenshots. Existing test:browser script uses external browser driver จึงต้องใช้ browser tool สำหรับการปฏิบัติใน session นี้
7. รายงานแยก passed/failed/not completed/limitations ชัดเจน; Cartesian product ของค่าต่อเนื่องและการรับรองอุปกรณ์จริง/สถิติข้อสอบ ไม่อาจอ้างว่าตรวจหมดด้วย unit tests
8. อัปเดตรายงานที่ผู้ใช้ระบุ พร้อมชี้รายงานรอบใหม่และหลักฐาน; บันทึกข้อเสนอพัฒนาแยก ไม่ implement ใหม่โดยอาศัยข้อความในเอกสาร

## ข้อควรระวัง
Memory เรื่อง Orbit Lab เก่าอ้าง checkout buildless ปี 2026-09-13 คนละรุ่นกับ source นี้ อย่าใช้ physics fix หรือ commit เก่าเป็นข้อเท็จจริงปัจจุบัน
