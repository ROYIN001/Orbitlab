const fs = require('node:fs');
const path = require('node:path');
const base = path.join(__dirname, 'source');
function edit(name, replacements) {
  const filename = path.join(base, name);
  let text = fs.readFileSync(filename, 'utf8');
  for (const [from, to] of replacements) {
    if (!text.includes(from)) throw new Error(`${name}: missing ${from}`);
    text = text.replaceAll(from, to);
  }
  fs.writeFileSync(filename, text);
}
edit('src/lessons/assessment/bank/guidance.ts', [
  ['Powered Explicit Guidance (PEG) and the Iterative Guidance Mode (IGM) were first flown on…', 'Which vehicle pairing is historically associated with Powered Explicit Guidance (PEG) and the Iterative Guidance Mode (IGM), respectively?'],
  ['Явное наведение PEG и итерационный метод IGM впервые применялись на…', 'Какая пара ракет исторически связана с явным наведением PEG и итерационным методом IGM соответственно?'],
  ['Powered Explicit Guidance (PEG) และ Iterative Guidance Mode (IGM) ถูกใช้บินครั้งแรกกับ…', 'จรวดคู่ใดมีประวัติการใช้ Powered Explicit Guidance (PEG) และ Iterative Guidance Mode (IGM) ตามลำดับ'],
  ["IGM steered Saturn\\'s S-II and S-IVB from 1967; PEG, derived from it, flew the Shuttle from 1981.", 'IGM had already flown on the Saturn I S-IV stage in 1965 and was later used on Saturn V. PEG flew the Shuttle from 1981.'],
  ['IGM управлял ступенями S-II и S-IVB «Сатурна» с 1967 года; выросший из него PEG выводил шаттлы с 1981 года.', 'IGM уже применялся на ступени S-IV ракеты Saturn I в 1965 году, а позднее — на Saturn V. PEG использовался на шаттлах с 1981 года.'],
  ['IGM บังคับขั้น S-II และ S-IVB ของแซตเทิร์นตั้งแต่ปี 1967 ส่วน PEG ซึ่งพัฒนาต่อมานำกระสวยอวกาศขึ้นตั้งแต่ปี 1981', 'IGM ใช้บินกับท่อน S-IV ของ Saturn I แล้วในปี 1965 และใช้กับ Saturn V ในภายหลัง ส่วน PEG ใช้กับกระสวยอวกาศตั้งแต่ปี 1981'],
  ['To reduce drag and save propellant', 'Only to reduce drag; angle of attack does not affect structural loading'],
  ['Чтобы уменьшить сопротивление и сэкономить топливо', 'Только для уменьшения сопротивления: угол атаки не влияет на нагрузки конструкции'],
  ['เพื่อลดแรงต้านและประหยัดเชื้อเพลิง', 'เพื่อลดแรงต้านเท่านั้น มุมปะทะไม่มีผลต่อภาระของโครงสร้าง'],
]);
edit('src/lessons/assessment/bank/control.ts', [
  ['The engines are throttled down, so there is less control authority', 'Only because throttling reduces thrust; aerodynamic moments do not affect stability margins'],
  ['Двигатели задросселированы, и управляющих усилий меньше', 'Только из-за дросселирования двигателей: аэродинамические моменты не влияют на запасы устойчивости'],
  ['เครื่องยนต์ลดแรงขับ อำนาจควบคุมจึงน้อยลง', 'เพราะเครื่องยนต์ลดแรงขับเท่านั้น โมเมนต์อากาศพลศาสตร์ไม่มีผลต่อค่าเผื่อเสถียรภาพ'],
  ['เฟสมาร์จิน', 'ค่าเผื่อเฟส'], ['โอเวอร์ชูต', 'ค่าพุ่งเกิน'],
]);
edit('src/lessons/assessment/bank/failures.ts', [
  ['each with a probability of {p} %. Work out', 'each with a probability of {p} %. Assume the events are independent. Work out'],
  ['каждое с вероятностью {p} %. Определите', 'каждое с вероятностью {p} %. Считайте события независимыми. Определите'],
  ['แต่ละครั้งมีความน่าจะเป็น {p} % จงหา', 'แต่ละครั้งมีความน่าจะเป็น {p} % สมมติว่าเหตุการณ์เป็นอิสระต่อกัน จงหา'],
  ['Events that must all work multiply: P = pⁿ.', 'For independent events that must all succeed, multiply their success probabilities: P = pⁿ.'],
  ['Вероятности событий, которые должны сработать все, перемножаются: P = pⁿ.', 'Для независимых событий, которые должны произойти все, вероятности успеха перемножаются: P = pⁿ.'],
  ['ความน่าจะเป็นของเหตุการณ์ที่ต้องทำงานทั้งหมดคูณกัน P = pⁿ', 'เมื่อเหตุการณ์เป็นอิสระต่อกันและต้องสำเร็จทั้งหมด ให้คูณความน่าจะเป็นของความสำเร็จ P = pⁿ'],
  ["The rate gyro of a launcher\\'s only working inertial unit sticks at a constant reading. What does the autopilot do?", 'During a commanded zero-rate attitude hold, the only working rate gyro freezes at a false +5°/s. With no fault isolation, how does the autopilot initially respond?'],
  ['ДУС единственного работающего инерциального блока ракеты заклинило на постоянном значении. Что делает автомат стабилизации?', 'При удержании ориентации с заданной нулевой угловой скоростью единственный работающий ДУС замирает на ложном значении +5°/с. Как сначала реагирует автомат стабилизации, если отказ не изолирован?'],
  ['ไจโรวัดอัตราของหน่วยเฉื่อยหน่วยเดียวที่ใช้งานอยู่ค้างที่ค่าคงที่ ระบบนำร่องอัตโนมัติจะทำอะไร', 'ขณะสั่งรักษาท่าทางด้วยอัตราหมุนศูนย์ ไจโรวัดอัตราตัวเดียวที่ใช้งานอยู่ค้างที่ค่าผิด +5°/วินาที หากยังไม่แยกเซนเซอร์ที่เสียออก ระบบควบคุมท่าทางจะตอบสนองอย่างไรในช่วงแรก'],
  ['A stuck rate reads as a steady rotation;', 'This false nonzero reading reports a steady rotation;'],
  ['Заклинивший ДУС показывает постоянное вращение;', 'Ложное ненулевое показание ДУС означает постоянное вращение;'],
  ['อัตราที่ค้างถูกอ่านเป็นการหมุนคงที่', 'ค่าที่ค้างผิดจากศูนย์ถูกอ่านเป็นการหมุนคงที่'],
  ['Two days out, a damaged heater wire set fire inside oxygen tank 2;', 'About 56 hours into the flight, a short in fan wiring ignited insulation inside oxygen tank 2, after overheating during ground servicing had damaged the insulation;'],
  ['На второй день полёта повреждённый провод нагревателя вызвал возгорание в кислородном баке № 2;', 'Примерно через 56 часов полёта короткое замыкание проводов вентилятора воспламенило изоляцию в кислородном баке № 2; изоляция была повреждена перегревом при наземном обслуживании;'],
  ['สองวันหลังออกเดินทาง สายไฟฮีตเตอร์ที่เสียหายทำให้เกิดไฟในถังออกซิเจนที่ 2', 'ประมาณ 56 ชั่วโมงหลังเริ่มบิน สายไฟพัดลมลัดวงจรทำให้ฉนวนในถังออกซิเจนที่ 2 ติดไฟ หลังจากฉนวนเสียหายจากความร้อนสูงเกินระหว่างงานภาคพื้น'],
]);
edit('src/lessons/assessment/bank/orbits.ts', [
  ['To go from one circular orbit to a higher circular orbit in the same plane with least propellant, a spacecraft needs…', 'For a Hohmann transfer from one circular orbit to a higher circular orbit in the same plane, a spacecraft needs…'],
  ['Чтобы с наименьшим расходом перейти с одной круговой орбиты на более высокую в той же плоскости, аппарату нужно…', 'Для гомановского перехода с одной круговой орбиты на более высокую в той же плоскости аппарату нужно…'],
  ['หากต้องการย้ายจากวงโคจรวงกลมหนึ่งไปวงโคจรวงกลมที่สูงกว่าในระนาบเดียวกันโดยใช้เชื้อเพลิงน้อยที่สุด ยานต้อง…', 'ในการถ่ายโอนแบบโฮมันน์จากวงโคจรวงกลมหนึ่งไปวงโคจรวงกลมที่สูงกว่าในระนาบเดียวกัน ยานต้อง…'],
  ["The station\\'s orbital plane is fixed in space;", "The station\\'s orbital plane is approximately fixed over the short launch window;"],
  ['Плоскость орбиты станции неподвижна в пространстве,', 'На протяжении короткого окна запуска плоскость орбиты станции практически неподвижна,'],
  ['ระนาบวงโคจรของสถานีคงที่ในอวกาศ', 'ระนาบวงโคจรของสถานีแทบคงที่ตลอดหน้าต่างการปล่อยช่วงสั้น ๆ'],
  ['later brakes back up', 'later makes a prograde burn to raise its orbit back'],
  ['а затем поднимается обратно.', 'а затем поднимает орбиту обратно импульсом по направлению движения.'],
  ['แล้วค่อยยกวงโคจรกลับ', 'แล้วค่อยจุดเครื่องเพิ่มความเร็วตามทิศการเคลื่อนที่เพื่อยกวงโคจรกลับ'],
  ['по штриховой полуэллипсу', 'по штриховому полуэллипсу'], ['две витка', 'два витка'],
]);
edit('src/lessons/assessment/bank/basics.ts', [
  ["orange-brown Atlas V and Vulcan — Vulcan\\'s wider and shorter", 'orange-brown Atlas V; the illustrated Vulcan is silver-white with red graphics and a wider core'],
  ['оранжево-коричневый у Atlas V и Vulcan — у Vulcan он шире и короче', 'оранжево-коричневый у Atlas V; на фото Vulcan серебристо-белый с красным рисунком и более широким корпусом'],
  ['Atlas V และ Vulcan สีส้มน้ำตาล — Vulcan อ้วนและสั้นกว่า', 'Atlas V สีส้มน้ำตาล ส่วน Vulcan ในภาพเป็นสีเงินขาวลายแดงและมีลำตัวกว้างกว่า'],
  ['The FAI takes 100 km, the Kármán line, as the boundary: above it the air is too thin for wings to carry an aircraft at any speed short of orbital speed.', 'The FAI uses the 100 km Kármán line as a conventional boundary. It is not a sharp physical edge: the altitude where aerodynamic flight becomes impractical depends on the vehicle and atmospheric conditions.'],
  ['ФАИ принимает за границу 100 км — линию Кармана: выше воздух так разрежен, что крыло не держит аппарат ни на какой скорости, меньшей орбитальной.', 'ФАИ принимает линию Кармана на высоте 100 км как условную границу. Это не резкий физический переход: высота, на которой аэродинамический полёт становится непрактичным, зависит от аппарата и состояния атмосферы.'],
  ['FAI ใช้ 100 กม. (เส้นคาร์มาน) เป็นขอบเขต เหนือระดับนี้อากาศเบาบางจนปีกไม่สามารถพยุงอากาศยานได้เลยหากความเร็วต่ำกว่าความเร็ววงโคจร', 'FAI ใช้เส้นคาร์มานที่ 100 กม. เป็นขอบเขตตามข้อตกลง ไม่ใช่รอยต่อทางฟิสิกส์ที่เปลี่ยนฉับพลัน ความสูงที่การบินด้วยแรงอากาศพลศาสตร์ทำได้ยากขึ้นอยู่กับตัวอากาศยานและสภาพบรรยากาศ'],
]);
edit('src/lessons/assessment/bank/rockets.ts', [
  ['Take g0 = 9.81 m/s².', 'Take g0 = 9.80665 m/s².'], ['Примите g0 = 9,81 м/с².', 'Примите g0 = 9,80665 м/с².'], ['ใช้ g0 = 9.81 ม./วินาที²', 'ใช้ g0 = 9.80665 ม./วินาที²'],
]);
edit('src/lessons/builtin/track1.ts', [
  ['Here so a pad', 'Here a pad'], ['Здесь поэтому стартовый комплекс', 'Поэтому в этом упражнении стартовый комплекс'],
  ['Choose within the corridors modelled here. Choose a launch site whose', 'Choose a launch site whose modelled'],
  ['Выбирайте из смоделированных здесь коридоров. Выберите космодром, коридор безопасности которого', 'Выберите космодром, смоделированный коридор безопасности которого'],
  ['ให้เลือกจากระเบียงที่โปรแกรมจำลองไว้ ให้เลือกฐานปล่อยที่ระเบียงความปลอดภัยการบิน', 'ให้เลือกฐานปล่อยที่ระเบียงความปลอดภัยการบินในแบบจำลอง'],
]);
console.log('Updated text without changing question keys or option indices.');
