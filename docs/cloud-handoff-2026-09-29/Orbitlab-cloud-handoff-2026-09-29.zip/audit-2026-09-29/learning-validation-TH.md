# ตรวจบทเรียนและแบบประเมิน — สถานะงาน 29 กันยายน 2026

แก้ใน `audit-2026-09-29/source` ยังไม่ push หรือ deploy **หยุดงานชุดนี้เพื่อส่งต่อ Codex Cloud ตามคำสั่งผู้ใช้** เอกสารนี้เป็น handoff ไม่ใช่คำยืนยันว่าผ่านการตรวจทั้งหมด

## ทำแล้วในรอบนี้

- อ่านรายงานเดิมและภาคผนวกบทเรียน/แบบประเมิน ตรวจ diff ที่มีอยู่โดยรักษาการแก้เดิมไว้
- ใช้ skill Russian–Thai translation เพื่อเทียบคำศัพท์ที่ผู้ใช้กำหนด ไม่แก้ glossary หรือ memory
- ยืนยันประเด็นที่จะแก้: ข้อสอบ PEG/IGM กล่าวถึงการใช้ครั้งแรกผิด, คำถามมุมปะทะ/เสถียรภาพมีตัวลวงที่เป็นเหตุผลจริง, series reliability ขาดสมมติฐานอิสระ, catch-up อธิบายทิศ burn ผิด และถ้อยคำบางจุดที่ตรวจพบในรายงานเดิม
- เลือกคง ID, ตำแหน่งตัวเลือก, correct flags, tolerance และสูตรให้เหมือนเดิม เพื่อไม่เปลี่ยนคะแนนคำตอบที่เคยบันทึกไว้ การเก็บ snapshot/version ของคลังข้อสอบครบชุดเป็นงานพัฒนาและยังไม่ทำ
- พบ diff ที่เพิ่ม draft บทเรียน, save warning, case input snapshot, rubric ประวัติศาสตร์, guidance lock และภาพในหน้าทบทวนแล้ว กำลังตรวจความครบและจะเพิ่ม regression tests ที่ตรงกับบั๊ก

## การแก้ที่เสร็จและตรวจแล้วก่อนส่งต่อ

แก้ข้อความใน `src/lessons/assessment/bank/{basics,orbits,rockets,guidance,control,failures}.ts` ทั้ง EN/RU/TH โดยคงโครงสร้างให้คะแนนไว้:

- PEG/IGM: ถามการจับคู่ที่ใช้จริงแทนกล่าวอ้างครั้งแรก; อธิบาย IGM บน Saturn I S-IV ปี 1965 ก่อน Saturn V
- มุมปะทะและ max-Q: เปลี่ยนตัวลวงให้กล่าวว่าเหตุผลนั้นเป็นเหตุผลเดียวและปฏิเสธผลต่อโครงสร้าง/เสถียรภาพอย่างชัดเจน จึงไม่ตีตราคำตอบที่เป็นประโยชน์จริงว่าเป็นความเข้าใจผิด
- Series reliability: เพิ่มสมมติฐานเหตุการณ์เป็นอิสระต่อกันในโจทย์และเฉลย
- Catch-up: ระบุการจุดเครื่องตามทิศการเคลื่อนที่เพื่อกลับสู่วงโคจรสูง; จำกัดโจทย์ two burns ให้เป็น Hohmann
- หน้าต่างปล่อย: ระนาบแทบคงที่เฉพาะช่วงสั้น; stuck gyro: ระบุค่าผิด +5°/s ขณะสั่งอัตราหมุนศูนย์
- Apollo 13: สายไฟพัดลมลัดวงจรหลังฉนวนเสียหายจากความร้อนสูงในงานภาคพื้น ไม่ใช่สายฮีตเตอร์เป็นตัวจุดไฟโดยตรง
- สี Vulcan ตามภาพ, Kármán เป็นขอบเขตตามข้อตกลง, ค่า g0 ในโจทย์ตรงกับสูตรเดิม
- แก้ไวยากรณ์ RU “по штриховому полуэллипсу”, “два витка” และใช้ “ค่าเผื่อเฟส/ค่าพุ่งเกิน” ให้ตรงกันใน control bank
- เกลาประโยค track1 ที่แก้ก่อนหน้านี้ซ้ำซ้อน และแก้ TypeScript narrowing ใน review ให้เข้าถึง `observe` เฉพาะ `choice`

| การตรวจที่รันจริง | ผล |
|---|---|
| `node node_modules/typescript/bin/tsc --noEmit` | ผ่าน ไม่มี diagnostics |
| focused `assessment.test.ts`, `lessons-ui-core.test.ts`, `case-lessons.test.ts` | **63/63 ผ่าน**, ไม่มี skipped — `learning-focused-results.json` |
| เทียบโครงสร้าง scoring ทั้ง 157 ข้อกับ inventory 28 ก.ย. | **ไม่มีการเปลี่ยน** ID/type/domain/level/kind/skill, correct flags ในตำแหน่งเดิม, จำนวน order items, params/expression/tolerance/unit, vehicle list หรือ lesson links — `learning-bank-compatibility.json` |
| ตรวจ 926 text triples (2,778 strings) | ไม่มีข้อความหายหรือ placeholder ไม่ตรงกัน |
| `git diff --check` | ผ่าน; มีคำเตือน LF/CRLF ของไฟล์ scene ซึ่งอีก agent แก้ ไม่ใช่ whitespace error |

สคริปต์ทำซ้ำ: `check-learning-bank.mjs` เป็น audit-only; `fix-learning-text.cjs` เป็นบันทึกการแทนข้อความ **ใช้ครั้งเดียวแล้ว ไม่ต้องรันซ้ำ**

## งานที่ยังเหลือ

1. เพิ่ม regression เฉพาะบั๊กสำหรับ raw drafts/การล้างคำตอบ, case data snapshot, site/guidance locks และกรณีผิด 100 kg Sputnik / 55° Vostok / 330,000 km Apollo; focused suite เดิมผ่านแต่ยังไม่ครอบคลุมทุก patch ใหม่
2. ตรวจ rubric ที่เพิ่มกับ worked flight solution และ counterexample; heavy/6-DOF อยู่ในความรับผิดชอบ physics agent ให้ดูรายงานรวมก่อนรันซ้ำ
3. ตรวจ browser workflows draft/hint/language ทั้ง flight numeric + case numeric/radio, review diagram/chart/photo และ storage refusal; root อาจมีหลักฐานแยก ให้รวมตามผลจริง
4. อ่านข้อความ EN/RU/TH ต่อเป็นส่วน ๆ: **ยังไม่ได้บรรณาธิกรอิสระครบทุกประโยค 157 ข้อ/24 บทในรอบนี้** การตรวจ 926 triples เป็นโครงสร้าง ไม่ใช่การรับรองการแปลทุกข้อความ
5. ตรวจคำอธิบาย physics limits ที่ยังบอกว่าไม่มี slosh/flex ทั้งที่เป็น optional feature (ไฟล์ i18n ร่วม ไม่ได้แก้ในชุดนี้)
6. งานพัฒนาที่บันทึกไว้ก่อน: เปลี่ยนนโยบาย reveal/retry, bank snapshots/versioning, backup/restore, attempt history, MC batch provenance, การตรวจ amplitude/hold/baseline ในบท 4.3 และการพาไปกราฟจาก feedback ยังไม่ได้ลงมือ

**ความต่อเนื่องของผลเก่า:** คีย์/ดัชนี/สูตรไม่เปลี่ยน จึงไม่เปลี่ยนคะแนนตัวเลือกเดิมจากชุดข้อความที่แก้ แต่หน้าทบทวนผลเก่ายังใช้ถ้อยคำของ bank ปัจจุบัน ไม่ได้มี immutable question snapshot แก้ recommendation logic อาจทำให้คำแนะนำเดิมต่างไปโดยคะแนนยังเท่าเดิม

## แหล่งหลักที่กำลังใช้อ้างอิง

- NASA SA-9 flight report: https://ntrs.nasa.gov/api/citations/19650014966/downloads/19650014966.pdf
- NASA Apollo 13 accident: https://nssdc.gsfc.nasa.gov/planetary/lunar/ap13acc.html
- Space Launch Delta 45 เรื่องการปล่อย polar/southerly จาก Florida: https://www.patrick.spaceforce.mil/News/Article-Display/Article/2889083/sld-45-to-support-multiple-southerly-trajectory-launches-in-new-year-urges-publ/
- FAI อธิบายเส้น Kármán เป็น convention และการอภิปรายขอบเขต: https://www.fai.org/news/statement-about-karman-line
- Arizona State lecture เรื่อง bi-elliptic เทียบ Hohmann: https://control.asu.edu/Classes/MAE462/462Lecture09.pdf

NASA SA-9 PDF เปิดตรงผ่าน web tool ได้ 403 แต่ search index ของเอกสาร NASA เดียวกันยืนยัน S-IV/IGM และวันปล่อย 16 ก.พ. 1965; ไม่อ้างว่าอ่าน PDF ฉบับเต็มสำเร็จในรอบนี้

ข้อจำกัด: ยังไม่มีการรับรองเชิงสถิติของข้อสอบหรือเปรียบเทียบ simulator กับข้อมูลบินจริง; unit tests และ inventory ไม่แทนการตรวจทุก browser/device/screen reader ทุก workflow
